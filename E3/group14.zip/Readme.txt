GetData.py : 取得資料
DataPreprocessing.py : 資料前處理
(訓練模型名稱).py : 訓練以及預測結果
report.pdf : 報告